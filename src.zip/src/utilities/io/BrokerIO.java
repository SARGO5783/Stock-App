package utilities.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import datacontainers.BrokerDataContainer;
import datamodels.Broker;
import exceptionhandlers.MyFileException;


public class BrokerIO  {

	   /**
	    * Constructor is declared private because the IO classes are utilities which
	    * contain static methods and should never be instantiated
	    */
	   private BrokerIO() {
	   }

	   
	   /**
	    * Writes out the Broker data in JSON format containing all Broker objects
	    * in the Broker data container
	    *
	    */
	   public static void writeJSONFile(String fileLocation, BrokerDataContainer datacontainer) throws MyFileException {

	      PrintWriter jsonFile = null;

	      try {
	         // Create output file
	         jsonFile = new PrintWriter(fileLocation + "/brokers.json");

	         // Create JSON object
	         Gson gson = new GsonBuilder().create();

	         // Convert broker list to JSON format
	         gson.toJson(datacontainer.getBrokerList(), jsonFile);

	      } catch (JsonIOException | FileNotFoundException exp) {
	         throw new MyFileException(exp.getMessage());
	      } finally {
	         // Flush the output stream and close the file
	         if (jsonFile != null) {
	            jsonFile.flush();
	            jsonFile.close();
	         }
	      }
	   }
	   
	   
	   /**
	    * Reads a JSON formatted file of brokers and returns an array list of
	    * Broker objects.
	    *
	    */
	   public static ArrayList<Broker> readJSONFile(String fileLocation) throws MyFileException {

	      ArrayList<Broker> listOfBrokers = new ArrayList<>();

	      try {
	         // Create input file
	         BufferedReader jsonFile = new BufferedReader(new FileReader(fileLocation + "/brokers.json"));

	         // Create JSON object
	         Gson gson = new GsonBuilder().create();

	         // fromJson returns an array
	         Broker[] brokerArray = gson.fromJson(jsonFile, Broker[].class);

	         // Convert to arraylist for the data model
	         listOfBrokers.addAll(Arrays.asList(brokerArray));
	         return listOfBrokers;
	      } catch (JsonIOException | JsonSyntaxException | FileNotFoundException exp) {
	         throw new MyFileException(exp.getMessage());
	      }
	   }
	   
	   	   
}	   