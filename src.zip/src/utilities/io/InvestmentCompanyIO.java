package utilities.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import datacontainers.InvestmentCompanyDataContainer;
import datamodels.InvestmentCompany;
import exceptionhandlers.MyFileException;


public class InvestmentCompanyIO  {

	   /**
	    * Constructor is declared private because the IO classes are utilities which
	    * contain static methods and should never be instantiated
	    */
	   private InvestmentCompanyIO() {
	   }

	   
	   /**
	    * Writes out the InvestmentCompany data in JSON format containing all InvestmentCompany objects
	    * in the InvestmentCompany data container
	    *
	    */
	   public static void writeJSONFile(String fileLocation, InvestmentCompanyDataContainer datacontainer) throws MyFileException {

	      PrintWriter jsonFile = null;

	      try {
	         // Create output file
	         jsonFile = new PrintWriter(fileLocation + "/companies.json");

	         // Create JSON object
	         Gson gson = new GsonBuilder().create();

	         // Convert company list to JSON format
	         gson.toJson(datacontainer.getCompanyList(), jsonFile);

	      } catch (JsonIOException | FileNotFoundException exp) {
	         throw new MyFileException(exp.getMessage());
	      } finally {
	         // Flush the output stream and close the file
	         if (jsonFile != null) {
	            jsonFile.flush();
	            jsonFile.close();
	         }
	      }
	   }
	   
	   
	   /**
	    * Reads a JSON formatted file of companies and returns an array list of
	    * InvestmentCompany objects.
	    *
	    */
	   public static ArrayList<InvestmentCompany> readJSONFile(String fileLocation) throws MyFileException {

	      ArrayList<InvestmentCompany> listOfCompanies = new ArrayList<>();

	      try {
	         // Create input file
	         BufferedReader jsonFile = new BufferedReader(new FileReader(fileLocation + "/companies.json"));

	         // Create JSON object
	         Gson gson = new GsonBuilder().create();

	         // fromJson returns an array
	         InvestmentCompany[] companyArray = gson.fromJson(jsonFile, InvestmentCompany[].class);

	         // Convert to arraylist for the data model
	         listOfCompanies.addAll(Arrays.asList(companyArray));
	         return listOfCompanies;
	      } catch (JsonIOException | JsonSyntaxException | FileNotFoundException exp) {
	         throw new MyFileException(exp.getMessage());
	      }
	   }
	   
	   	   
}	   