/*
 * Listens for events on the menu form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controllers;

import controllers.reportformcontrollers.ListAllStockQuotesController;
import controllers.reportformcontrollers.ListAllInvestmentCompaniesController;
import controllers.reportformcontrollers.ListAllBrokersController;
import controllers.reportformcontrollers.ListAllInvestorsController;

import controllers.inputformcontrollers.InputStockQuoteFormController;
import controllers.inputformcontrollers.InputInvestmentCompanyFormController;
import controllers.inputformcontrollers.InputBrokerFormController;
import controllers.inputformcontrollers.InputInvestorFormController;

import java.awt.event.ActionListener;

import datacontainers.StockQuoteDataContainer;
import datacontainers.InvestmentCompanyDataContainer;
import datacontainers.BrokerDataContainer;
import datacontainers.InvestorDataContainer;

import exceptionhandlers.DatabaseException;
import exceptionhandlers.DatabaseErrorPopup;
import exceptionhandlers.MyFileException;
import java.util.logging.Level;
import java.util.logging.Logger;

import utilities.db.DatabaseIO;

import view.MainMenu;

public class MainMenuController implements ActionListener {

    // File location to store output files
    private String fileLocation;

    // Log file location;
    private String logfilelocation;

    // The data models are instantiated here and passed to the 
    // constructors for the controllers
    private StockQuoteDataContainer stockQuoteDataContainer = new StockQuoteDataContainer();
    private InvestmentCompanyDataContainer investmentCompanyDataContainer = new InvestmentCompanyDataContainer();
    private BrokerDataContainer brokerDataContainer = new BrokerDataContainer();
    private InvestorDataContainer investorDataContainer = new InvestorDataContainer();

    /**
     * Constructor
     *
     */
    public MainMenuController(String fileLocation, String logfilelocation) {
        this.fileLocation = fileLocation;
        this.logfilelocation = logfilelocation;
    }

    // The main menu form gets created here. Notice it takes this controller object
    // as an argument to the constructor
    private MainMenu mainMenu = new MainMenu(this);

    /**
     * The ActionListener interface contains a single method, actionPerformed
     */
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String menuItemClicked = event.getActionCommand();

        // create the controller which will open the correct form (refer to the controller constructor
        // methods do determine which data container classes need to be passed to the controller constructors)
        if (menuItemClicked.equals("Add Stock Quote")) {
            InputStockQuoteFormController inputController = new InputStockQuoteFormController(stockQuoteDataContainer);

        } else if (menuItemClicked.equals("List Available Stocks")) {
            ListAllStockQuotesController reportController = new ListAllStockQuotesController(stockQuoteDataContainer);

        } else if (menuItemClicked.equals("Add Investment Company")) {
            // Create an input form controller object for the investment company and pass the correct containers to the constructor
            InputInvestmentCompanyFormController inputController = new InputInvestmentCompanyFormController(investmentCompanyDataContainer, brokerDataContainer);

        } else if (menuItemClicked.equals("List Investment Companies")) {
            // Create a report controller object for the investment companies and pass the correct containers to the constructor  
            ListAllInvestmentCompaniesController reportController = new ListAllInvestmentCompaniesController(investmentCompanyDataContainer);

        } else if (menuItemClicked.equals("Add Broker")) {
            // Create an input form controller object for the broker and pass the correct containers to the constructor
            InputBrokerFormController inputController = new InputBrokerFormController(brokerDataContainer, investorDataContainer);

        } else if (menuItemClicked.equals("List Brokers")) {
            // Create a report controller object for the brokers and pass the correct containers to the constructor  
            ListAllBrokersController reportController = new ListAllBrokersController(brokerDataContainer);

        } else if (menuItemClicked.equals("Add Investor")) {
            // Create an input form controller object for the investor and pass the correct containers to the constructor
            InputInvestorFormController inputController = new InputInvestorFormController(investorDataContainer, stockQuoteDataContainer);

        } else if (menuItemClicked.equals("List Investors")) {
            // Create a report controller object for the investors and pass the correct containers to the constructor  
            ListAllInvestorsController reportController = new ListAllInvestorsController(investorDataContainer);

        } else if (menuItemClicked.equals("Exit")) {
            System.exit(0);

        } else if (menuItemClicked.equals("Save Data")) {
            try {
                DatabaseIO.storeStockQuotes(stockQuoteDataContainer);
                DatabaseIO.storeInvestors(investorDataContainer);
                DatabaseIO.storeBrokers(brokerDataContainer);
                DatabaseIO.storeInvestmentCompany(investmentCompanyDataContainer);
            } catch (DatabaseException exp) {
                new DatabaseErrorPopup(mainMenu, exp);
            }

        } else if (menuItemClicked.equals("Load Data")) {

            try {
                stockQuoteDataContainer.setStockQuoteList(DatabaseIO.retrieveStockQuotes());
                investorDataContainer.setInvestorList(DatabaseIO.retrieveInvestors());
                brokerDataContainer.setBrokerList(DatabaseIO.retrieveBrokers());
                investmentCompanyDataContainer.setCompanyList(DatabaseIO.retrieveInvestmentCompanies());
            } catch (DatabaseException | MyFileException exp) {
                 new DatabaseErrorPopup(mainMenu, exp);
            } 
        }
    }

    // Getter used in the Application.java class
    public MainMenu getMainMenu() {
        return mainMenu;
    }
}
