package datamodels;

import utilities.date.DateFunctions;
import exceptionhandlers.MyFileException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

/**
 * This class creates an Broker object
 */
public class Broker extends Person {


    private Calendar dateOfHire;
    private Calendar dateOfTermination;
    private double salary;
    private String status;
    private List<Investor> listOfClients;


    //------------------------------------------------------------------------------------------
    //  Constructors
    //------------------------------------------------------------------------------------------

    /**
     * Constructs a Broker object with no arguments
     */
    public Broker() {
        this.listOfClients = new ArrayList<Investor>();
    }

    /**
     * Constructs a Broker object with id, name, address, dateOfBirth, dateOfHire, dateOfTermination,
     * salary and status arguments
     * @param id                    the ID of the Broker object
     * @param name                  the name of the Broker object
     * @param address               the address of the Broker object
     * @param dateOfBirth           the date of birth of the Broker object
     * @param dateOfHire            the date of hire of the Broker object
     * @param dateOfTermination     the date of termination of the Broker object
     * @param salary                the salary of the Broker object
     * @param status                the status of the Broker object
     */
    public Broker(long id, String name, String address, Calendar dateOfBirth, Calendar dateOfHire, 
    			  Calendar dateOfTermination, double salary, String status) 
    					  throws MyFileException {
        super(id, name, address, dateOfBirth);
        this.dateOfHire = dateOfHire;
        this.dateOfTermination = dateOfTermination;
        this.salary = salary;
        this.status = status;
        this.listOfClients = new ArrayList<Investor>();
    }


    //------------------------------------------------------------------------------------------
    //  Getters & Setters
    //------------------------------------------------------------------------------------------

    /**
     * Gets the date of hire of the Broker object
     * @return dateOfHire   the date of hire of the Broker object
     */
    public Calendar getDateOfHire() { return dateOfHire; }

    /**
     * Sets the date of hire of the Broker object
     * @param dateOfHire    the date of hire of the Broker object
     */
    public void setDateOfHire(Calendar dateOfHire) { this.dateOfHire = dateOfHire; }

    /**
     * Gets the date of termination of the Broker object
     * @return dateOfTermination   the date of termination of the Broker object
     */
    public Calendar getDateOfTermination() { return dateOfTermination; }

    /**
     * Sets the date of termination of the Broker object
     * @param dateOfTermination    the date of termination of the Broker object
     */
    public void setDateOfTermination(Calendar dateOfTermination) { this.dateOfTermination = dateOfTermination; }

    /**
     * Gets the salary of the Broker object
     * @return salary   the salary of the Broker object
     */
    public double getSalary() { return salary; }

    /**
     * Sets the salary of the Broker object
     * @param salary    the salary of the Broker object
     * @throws MyFileException
     */
    public void setSalary(double salary) throws MyFileException {
        if (salary <= 0) {
            throw new MyFileException("Setting broker salary failed, salary must be greater than zero.  Invalid broker salary: " + salary);
        } else {
    	this.salary = salary; }
    }

    /**
     * Gets the status of the Broker object
     * @return status   the status of the Broker object
     */
    public String getStatus() { return status; }

    /**
     * Sets the status of the Broker object
     * @param status    the status of the Broker object
     * @throws MyFileException
     */
    public void setStatus(String status) throws MyFileException {
        if (!status.equals("Fulltime")  &&  !status.equals("Parttime")) {
            throw new MyFileException("Setting broker status failed, status must be Fulltime or Parttime (case sensitive).  Invalid broker status: >" + status + "<");
        } else {
    	this.status = status; }
    }
    

    /**
     * Gets the list of clients (investors) associated with the Broker object
     * @return listOfClients    the list of clients (investors) associated with the Broker object
     */
    public List<Investor> getListOfClients() { return listOfClients; }


    //------------------------------------------------------------------------------------------
    //  Class Methods
    //------------------------------------------------------------------------------------------

    /**
     * Adds a client to the list of clients associated with the Broker
     * @param newClient     a new Investor to be associated with the Broker
     */
    public void addClient(Investor newClient) { listOfClients.add(newClient); }


    //------------------------------------------------------------------------------------------
    //  Equals & Hash
    //------------------------------------------------------------------------------------------

    /**
     * Compares two Broker objects to determine equality
     * @param o     object being compared
     * @return true if members are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Broker broker = (Broker) o;
        return Double.compare(broker.salary, salary) == 0 && Objects.equals(dateOfHire, broker.dateOfHire) && Objects.equals(dateOfTermination, broker.dateOfTermination) && Objects.equals(status, broker.status) && Objects.equals(listOfClients, broker.listOfClients);
    }

    /**
     * Creates hash code for a Broker object
     * @return hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), dateOfHire, dateOfTermination, salary, status, listOfClients);
    }


    //------------------------------------------------------------------------------------------
    //  toString
    //------------------------------------------------------------------------------------------

    /**
     * Creates a string representation of a Broker object
     * @return string representation of a Broker object
     */
    @Override
    public String toString() {
        return super.toString()
            + ", {\"Broker\":{"
            + "\"dateOfHire\":\"" + DateFunctions.dateToString(this.dateOfHire) + "\""
            + ", \"dateOfTermination\":\"" + DateFunctions.dateToString(this.dateOfTermination) + "\""
            + ", \"salary\":\"" + this.salary + "\""
            + ", \"status\":\"" + this.status + "\""
            + ", \"listOfClients\":\"" + this.listOfClients + "\""
            + "}}";
        }

}
