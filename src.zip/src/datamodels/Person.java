package datamodels;

import utilities.date.DateFunctions;
import exceptionhandlers.MyFileException;

import java.util.Calendar;
import java.util.Objects;


/**
 * This class creates a Person object
 */
public class Person {

    private long id;                    // id of the person
    private String name;                // name of the person
    private String address;             // address of the person
    private Calendar dateOfBirth;       // date of birth of the person


    //------------------------------------------------------------------------------------------
    //  Constructors
    //------------------------------------------------------------------------------------------

    /**
     * Constructs a Person object with no arguments
     */
    public Person() {
    }

    /**
     * Constructs an Person object with id, name, address and dateOfBirth arguments
     * @param id            the ID of the Person object
     * @param name          the name of the Person object
     * @param address       the address of the Person object
     * @param dateOfBirth   the date of birth of the Person object
     */
    public Person(long id, String name, String address, Calendar dateOfBirth) 
    		throws MyFileException {
        if (name.isEmpty()) {
    		throw new MyFileException("Creating Person failed, name not specified");
    	}
        this.id = id;
        this.name = name;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
    }

    //------------------------------------------------------------------------------------------
    //  Getters & Setters
    //------------------------------------------------------------------------------------------

    /**
     * Gets the id of the Person object
     * @return id   the ID of the Person object
     */
    public long getId() { return id; }

    /**
     * Gets the id of the Person object
     * @param id    the ID of the Person object
     * @throws MyFileException
     */
    public void setId(long id) throws MyFileException { 
        if (id <= 0) {
            throw new MyFileException("Setting id failed, id must be greater than zero.  Invalid id: " + id);
        } else {
    	this.id = id;
    	}
    }

    /**
     * Gets the name of the Person object
     * @return name     the name of the Person object
     */
    public String getName() { return name; }

    /**
     * Sets the name of the Person object
     * @param name      the name of the Person object
     * @throws MyFileException 
     */
    public void setName(String name) throws MyFileException {
        if (name.isEmpty()) {
            throw new MyFileException("Setting name failed, no name specified");
        } else {
        	this.name = name;
        }
    }    

    /**
     * Gets the address of the Person object
     * @return address  the address of the Person object
     */
    public String getAddress() { return address; }

    /**
     * Sets the address of the Person object
     * @param address   the address of the Person object
     * @throws MyFileException
     */
    public void setAddress(String address) throws MyFileException {
        if (address.isEmpty()) {
            throw new MyFileException("Setting address failed, no address specified");
        } else {
    	this.address = address;
    	}
    }

    /**
     * Gets the date of birth of the Person object
     * @return dateOfBirth  the date of birth of the Person object
     */
    public Calendar getDateOfBirth() { return dateOfBirth; }

    /**
     * Sets the date of birth of the Person object
     * @param dateOfBirth   the date of birth of the Person object
     */
    public void setDateOfBirth(Calendar dateOfBirth) { this.dateOfBirth = dateOfBirth; }


    //------------------------------------------------------------------------------------------
    //  Equals & Hash
    //------------------------------------------------------------------------------------------

    /**
     * Compares two Person objects to determine equality
     * @param o     object being compared
     * @return true if members are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return id == person.id && Objects.equals(name, person.name) && Objects.equals(address, person.address) && Objects.equals(dateOfBirth, person.dateOfBirth);
    }

    /**
     * Creates hash code for a Person object
     * @return hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(id, name, address, dateOfBirth);
    }


    //------------------------------------------------------------------------------------------
    //  toString
    //------------------------------------------------------------------------------------------

    /**
     * Creates a string representation of a Person object
     * @return string representation of an Person object
     */
    @Override
    public String toString() {
        return "{\"Person\":{"
                + "\"name\":\"" + this.name + "\""
                + ", \"address\":\"" + this.address + "\""
                + ", \"dateOfBirth\":\"" + DateFunctions.dateToString(this.dateOfBirth) + "\""
                + ", \"id\":\"" + this.id + "\""
                + "}}";
    }



}

