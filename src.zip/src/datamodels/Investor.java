package datamodels;

import utilities.date.DateFunctions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

import exceptionhandlers.MyFileException;


/**
 * This class creates an Investor object
 */
public class Investor extends Person {


    private Calendar memberSince;                   // member since date of Investor
    private List<InvestorStockQuote> listOfStocks;  // list of Investor stocks


    //------------------------------------------------------------------------------------------
    //  Constructors
    //------------------------------------------------------------------------------------------

    /**
     * Constructs an Investor object with no arguments
     */
    public Investor() {
        this.listOfStocks = new ArrayList<InvestorStockQuote>();
    }

    /**
     * Constructs an Investor object with id, name, address, dateOfBirth and memberSince arguments
     * and creates an empty listOfStocks
     * @param id            the ID of the Investor object
     * @param name          the name of the Investor object
     * @param address       the address of the Investor object
     * @param dateOfBirth   the date of birth of the Investor object
     * @param memberSince   the member since date of the Investor object
     */
    public Investor(long id, String name, String address, Calendar dateOfBirth, Calendar memberSince) 
    		throws MyFileException {
        super(id, name, address, dateOfBirth);
        this.memberSince  = memberSince;
        this.listOfStocks = new ArrayList<InvestorStockQuote>();
    }

    //------------------------------------------------------------------------------------------
    //  Getters & Setters
    //------------------------------------------------------------------------------------------

    /**
     * Gets the member since date of the Investor object
     * @return memberSince   the member since date of the Investor object
     */
    public Calendar getMemberSince() { return memberSince; }

    /**
     * Sets the member since date of the Investor object
     * @param memberSince   the member since date of the Investor object
     */
    public void setMemberSince(Calendar memberSince) { this.memberSince = memberSince; }

    /**
     * Gets the list of stocks associated with the Investor object
     * @return listOfStocks     list of stocks associated with the Investor object
     */
    public List<InvestorStockQuote> getListOfStocks() { return listOfStocks; }


    //------------------------------------------------------------------------------------------
    //  Class Methods
    //------------------------------------------------------------------------------------------

    /**
     * Adds a new stock to the list of stocks associated with the Investor
     * @param value     a stock from an InvestorStockQuote object
     */
    public void addStock(InvestorStockQuote value) {
        listOfStocks.add(value);
    }

    /**
     * Loops the stocks in the portfolio of the Investor, calculates the value of
     * each stock holding, and accumulates the values in accountValue
     * @return accountValue     total value of the account of the Investor
     */
    public double getAccountValue() {

        double accountValue = 0.0;

        for (InvestorStockQuote stock : listOfStocks) {
            accountValue += stock.getStock().getValue() * stock.getShares();
        }
        return accountValue;
    }


    //------------------------------------------------------------------------------------------
    //  Equals & Hash
    //------------------------------------------------------------------------------------------

    /**
     * Compares two Investor objects to determine equality
     * @param o     object being compared
     * @return true if members are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Investor investor = (Investor) o;
        return Objects.equals(memberSince, investor.memberSince) && Objects.equals(listOfStocks, investor.listOfStocks);
    }

    /**
     * Creates hash code for an Investor object
     * @return hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), memberSince, listOfStocks);
    }


    //------------------------------------------------------------------------------------------
    //  toString
    //------------------------------------------------------------------------------------------

    /**
     * Creates a string representation of an Investor object
     * @return string representation of an Investor object
     */
    @Override
    public String toString() {
        return super.toString()
                + ", {\"Investor\":{"
                + "\"memberSince\":\"" + DateFunctions.dateToString(this.memberSince) + "\""
                + ", \"listOfStocks\":\"" + this.listOfStocks + "\""
                + ", \"accountValue\":\"" + this.getAccountValue() + "\""
                + "}}";
    }
}
