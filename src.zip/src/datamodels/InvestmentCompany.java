package datamodels;

import exceptionhandlers.MyFileException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * This class creates an InvestmentCompany object
 */
public class InvestmentCompany {

    private String companyName;
    private List<Broker> listOfBrokers;

    //------------------------------------------------------------------------------------------
    //  Constructors
    //------------------------------------------------------------------------------------------

    /**
     * Constructs an InvestmentCompany object with no arguments
     */
    public InvestmentCompany() {this.listOfBrokers = new ArrayList<Broker>();}

    /**
     * Constructs an InvestmentCompany object with companyName as a parameter and creates
     * an empty listOfBrokers
     * @param companyName       name of the InvestmentCompany object
     */
    public InvestmentCompany(String companyName) 
    		throws MyFileException {
        if (companyName.isEmpty()) {
            throw new MyFileException("Creating InvestmentCompany failed, company name not specified");
        }
        this.companyName = companyName;
        this.listOfBrokers = new ArrayList<Broker>();
    }

    /**
     * Constructs an InvestmentCompany object with companyName and a listOfBrokers as parameters
     * @param companyName       name of the InvestmentCompany object
     * @param listOfBrokers     list of brokers of the InvestmentCompany object
     */
    public InvestmentCompany(String companyName, List<Broker> listOfBrokers) 
    		throws MyFileException {
        if (companyName.isEmpty()) {
            throw new MyFileException("Creating InvestmentCompany failed, company name not specified");
        }
        this.companyName = companyName;
        this.listOfBrokers = listOfBrokers;
    }


    //------------------------------------------------------------------------------------------
    //  Getters & Setters
    //------------------------------------------------------------------------------------------

    /**
     * Gets the company name of the InvestmentCompany object
     * @return companyName      the company name of the InvestmentCompany object
     */
    public String getCompanyName() { return companyName; }

    /**
     * Sets the company name of the InvestmentCompany object
     * @param companyName       the company name of the InvestmentCompany object
     * @throws MyFileException
     */
    public void setCompanyName(String companyName) throws MyFileException {
        if (companyName.isEmpty()) {
            throw new MyFileException("Setting investment company name failed, no company name specified");
        } else {
    	this.companyName = companyName; }
    }

    /**
     * Gets the list of brokers associated with the InvestmentCompany object
     * @return listOfBrokers    list of brokers associated with the InvestmentCompany object
     */
    public List<Broker> getListOfBrokers() { return listOfBrokers; }


    //------------------------------------------------------------------------------------------
    //  Class Methods
    //------------------------------------------------------------------------------------------

    /**
     * Adds a new broker to the list of brokers associated with the InvestmentCompany
     * @param newBroker     a new Broker object to be associated with the InvestmentCompany
     */
    public void addBroker(Broker newBroker) { listOfBrokers.add(newBroker); }


    //------------------------------------------------------------------------------------------
    //  Equals & Hash
    //------------------------------------------------------------------------------------------

    /**
     * Compares two InvestmentCompany objects to determine equality
     * @param o     object being compared
     * @return true if members are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvestmentCompany that = (InvestmentCompany) o;
        return Objects.equals(companyName, that.companyName) && Objects.equals(listOfBrokers, that.listOfBrokers);
    }

    /**
     * Creates hash code for an InvestmentCompany object
     * @return hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(companyName, listOfBrokers);
    }


    //------------------------------------------------------------------------------------------
    //  toString
    //------------------------------------------------------------------------------------------

    /**
     * Creates a string representation of an InvestmentCompany object
     * @return string representation of an InvestmentCompany object
     */
    @Override
    public String toString() {
        return "{\"InvestmentCompany\":{"
                + "\"companyName\":\"" + this.companyName + "\""
                + ", \"listOfBrokers\":\"" + this.listOfBrokers + "\""
                + "}}";
    }
}
