package datamodels;

import java.util.Objects;

/**
 * This class creates an InvestorStockQuote object
 */
public class InvestorStockQuote {

    private StockQuote stock;   // a StockQuote object containing the tickerSymbol, value and quoteDate
    private int shares;         // number of shares of the stock


    //------------------------------------------------------------------------------------------
    //  Constructors
    //------------------------------------------------------------------------------------------

    /**
     * Constructs an InvestorStockQuote object with no arguments
     */
    public InvestorStockQuote() {
    }

    /**
     * Constructs an InvestorStockQuote object with stock and shares arguments
     * @param stock     a StockQuote object containing the ticker symbol, value and quoteDate
     * @param shares    number of shares of the stock
     */
    public InvestorStockQuote(StockQuote stock, int shares) {
        this.stock = stock;
        this.shares = shares;
    }


    //------------------------------------------------------------------------------------------
    //  Getters & Setters
    //------------------------------------------------------------------------------------------

    /**
     * Gets a stockQuote object
     * @return stock   a StockQuote object containing the tickerSymbol, value and quoteDate
     */
    public StockQuote getStock() { return stock; }

    /**
     * Sets a stockQuote object
     * @param stock     a StockQuote object containing the tickerSymbol, value and quoteDate
     */
    public void setStock(StockQuote stock) { this.stock = stock; }

    /**
     * Gets the number of shares of a stock
     * @return shares   number of shares of a stock
     */
    public int getShares() { return shares; }

    /**
     * Sets the number of shares of a stock
     * @param shares    number of shares of a stock
     */
    public void setShares(int shares) { this.shares = shares; }


    //------------------------------------------------------------------------------------------
    //  Equals & Hash
    //------------------------------------------------------------------------------------------

    /**
     * Compares two InvestorStockQuote objects to determine equality
     * @param o     object being compared
     * @return true if members are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvestorStockQuote that = (InvestorStockQuote) o;
        return shares == that.shares && Objects.equals(stock, that.stock);
    }

    /**
     * Creates hash code for an InvestorStockQuote object
     * @return hash code
     */
    @Override
    public int hashCode() {
        return Objects.hash(stock, shares);
    }


    //------------------------------------------------------------------------------------------
    //  toString
    //------------------------------------------------------------------------------------------

    /**
     * Creates a string representation of an InvestorStockQuote object
     * @return string representation of an InvestorStockQuote object
     */
    @Override
    public String toString() {
        return "{\"InvestorStockQuote\":{"
                + "\"stock\":\"" + this.stock + "\""
                + ", \"shares\":\"" + this.shares + "\""
                + "}}";
    }
}

