/*
 *  This Class contains several containers which can hold Broker objects
 *  created in the UI
 */
package datacontainers;

import datamodels.Broker;
import java.util.ArrayList;
import java.util.List;

public class BrokerDataContainer  {

    /** Simple container that stores elements as a list, can contain duplicates
     *  Stores in FIFO order
     */
    private List<Broker> brokerList = new ArrayList<>();    // list of Broker objects


    /**
     * Gets the list of Broker objects
     * @return brokerList   the list of Broker objects
     */
    public List<Broker> getBrokerList() { return brokerList; }

    /**
     * Sets the list of Broker objects
     * @param brokerList    the list of Broker objects
     */
    public void setBrokerList(List<Broker> brokerList) { this.brokerList = brokerList; }

}
