/*
 *  This Class contains several containers which can hold InvestmentCompany objects
 *  created in the UI
 */
package datacontainers;

import datamodels.InvestmentCompany;
import java.util.ArrayList;
import java.util.List;

public class InvestmentCompanyDataContainer {

    /**
     * Simple container that stores elements as a list, can contain duplicates
     * Stores in FIFO order
     */
    private List<InvestmentCompany> companyList = new ArrayList<>();    // list of investment company objects


    /**
     * Gets the list of InvestmentCompany objects
     *
     * @return companyList   the list of InvestmentCompany objects
     */
    public List<InvestmentCompany> getCompanyList() { return companyList; }

    /**
     * Sets the list of InvestmentCompany objects
     *
     * @param companyList the list of InvestmentCompany objects
     */
    public void setCompanyList(List<InvestmentCompany> companyList) { this.companyList = companyList; }

}